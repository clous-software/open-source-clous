""" admin.py """
from django.contrib import admin
from django.contrib.contenttypes.admin import GenericStackedInline
from .models import News, Blog, HRTalks, Research, Guide, HelpCenter, ContentSection


# Inline para ContentSection, permitiendo edición en la misma página que el modelo principal
class ContentSectionInline(GenericStackedInline):
    model = ContentSection
    extra = 1


# Clase genérica de admin para manejar campos comunes de ContentBase
class ContentModelAdmin(admin.ModelAdmin):
    list_display = ('title', 'author','view_count', 'yes_count', 'status', 'created_at', 'updated_at')
    readonly_fields = ('created_at', 'updated_at', 'view_count', 'no_count', 'yes_count', 'slug')
    search_fields = ['title']
    list_filter = ('status',)
    
    inlines = [ContentSectionInline]

    fieldsets = (
        (None, {'fields': ('title', 'cover', 'introduction', 'conclusion', 'reading_time', 'slug', 
                           'status', 'created_at', 'updated_at', 'view_count', 'no_count', 'yes_count')}),
    )

    def get_readonly_fields(self, request, obj=None):
        readonly_fields = super().get_readonly_fields(request, obj)
        if not request.user.is_superuser:
            readonly_fields += ('status',)
        return readonly_fields

    def save_model(self, request, obj, form, change):
        if not obj.pk:  # Si es una creación, no una actualización
            print(f"User Profile Data: {request.user}")

            # Ajusta esto según tu modelo de datos
            if hasattr(obj, 'author'):
                obj.author = request.user
            elif hasattr(obj, 'user'):
                obj.user = request.user.useraccount.user
        super().save_model(request, obj, form, change)

# Clases específicas para Blog y Guide para manejar campos adicionales
class BlogAdmin(ContentModelAdmin):
    list_display = ContentModelAdmin.list_display + ('category',)
    fieldsets = ContentModelAdmin.fieldsets + ((None, {'fields': ('category',)}),)


class GuideAdmin(ContentModelAdmin):
    list_display = ContentModelAdmin.list_display + ('video',)
    fieldsets = ContentModelAdmin.fieldsets + ((None, {'fields': ('video',)}),)


# Registro de los modelos con sus clases de admin específicas
admin.site.register(Blog, BlogAdmin)
admin.site.register(Guide, GuideAdmin)
admin.site.register(News, ContentModelAdmin)
admin.site.register(HRTalks, ContentModelAdmin)
admin.site.register(Research, ContentModelAdmin)
admin.site.register(HelpCenter, ContentModelAdmin)
