# backend/settings/production.py
from .base import *

DEBUG = env.bool('DEBUG', default=False)

ALLOWED_HOSTS = env.list('ALLOWED_HOSTS')

CORS_ALLOWED_ORIGINS = env.list('CORS_ALLOWED_ORIGINS', default=['http://localhost:3000'])

# Configuración de la base de datos de producción
DATABASES = {
    'default': env.db('PROD_DB_URL')
}
